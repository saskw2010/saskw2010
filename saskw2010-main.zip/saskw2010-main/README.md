<div id="header" align="center">
  <img src="https://github.com/saskw2010/saskw2010/blob/main/20220223234204.gif"  width="600" height="300"/>
  <div align="center">
   <h1>
    hey there
    <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="30px"/>
  </h1>
  <img src="https://media.giphy.com/media/dWesBcTLavkZuG35MI/giphy.gif" width="600" height="300"/>
</div>
<div align="center">
   <h1>👋 Hi I’m @saskw2010 (This is Mostafa (A) ElNagar) </h1>   
(Senior Full stack Developer and system architect)/(Machine Learning engineer) /Co-Founder- wytSKY Clouding Solutions
<h3> I build Full Stack Solutions using a variety of Technologies: </h3>
</div>
</div>
  
 ## Github Stats :
 <div id="header1" align="center">
  
[![GitHub stats](https://github-readme-stats.vercel.app/api?username=saskw2010&count_private=true&show_icons=true)](https://github.com/saskw2010/github-readme-stats)

  
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=saskw2010&layout=compact&theme=radical&langs_count=10&custom_title=MostUsedLanguagesPart1&hide=php,scss,css,html,handlebars,TSQL,gherkin&card_width=600)

  
  ![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=saskw2010&layout=compact&theme=radical&langs_count=10&custom_title=MostUsedLanguagesPart2&hide=ASP.NET,Visual%Basic.NET,TypeScript,JavaScript,python,c%23&card_width=600)

  </div>
  
  <div id="badges"  align="center">
    
[![Gmail Badge](https://img.shields.io/badge/-wytsky.com-c14438?style=flat&logo=Gmail&logoColor=white&link=mailto:saskw2010@gmail.com)](mailto:saskw2010@gmail.com) 
[![Linkedin Badge](https://img.shields.io/badge/-mostafa.a.elnagar-0072b1?style=flat&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/mostafa-a-elnagar/)](https://www.linkedin.com/in/mostafa-a-elnagar/)
[![Portfolio Badge](https://img.shields.io/badge/portfolio-web-blue?style=flat&link=https://saskw2010.github.io/)](https://saskw2010.github.io/)
[![Portfolio Badge](https://img.shields.io/badge/portfolio-web-blue?style=flat&link=https://wytsky.com/)](https://wytsky.com/)
 
  </div>
  <div id="badges"  align="center">
    <a href="https://www.linkedin.com/in/mostafa-a-elnagar" target="_blank">
         <img src="https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn Badge"/>
    </a>
    <a href="https://www.youtube.com/channel/UCgnV-yHUyAN6y2amvdxF2oQ" target="_blank">
      <img src="https://img.shields.io/badge/YouTube-red?style=for-the-badge&logo=youtube&logoColor=white" alt="Youtube Badge"/>
    </a>
    <a href="https://twitter.com/wyt_sky" target="_blank">
      <img src="https://img.shields.io/badge/Twitter-blue?style=for-the-badge&logo=twitter&logoColor=white" alt="Twitter Badge"/>
    </a>
  </div>
 
 
</div>



<!---
<div align="center">
<h1>  More About Me (Mostafa (A) ElNagar)   </h1>
</div>

[![Gmail Badge](https://img.shields.io/badge/-wytsky.com-c14438?style=flat&logo=Gmail&logoColor=white&link=mailto:m.nagar@wytsky.com)](mailto:m.nagar@wytsky.com) 
[![Linkedin Badge](https://img.shields.io/badge/-mostafa.ah.elnagar-0072b1?style=flat&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/mostafa.a.elnagar/)](https://www.linkedin.com/in/mostafa.a.elnagar/)
[![Portfolio Badge](https://img.shields.io/badge/portfolio-web-blue?style=flat&link=https://saskw2010.github.io/)](https://saskw2010.github.io/)
[![Portfolio Badge](https://img.shields.io/badge/portfolio-web-blue?style=flat&link=https://wytsky.com/)](https://wytsky.com/)

--->
<div>
  <h3> Ai Optimal Enterprise solutions </h3>
</div>
<br/>

- 👀 I’m interested in c#,DotNet,Xamarin,Blazor,Maui,DotNet Core ,Machine learning,python,VB.net,API,Windows Services...
- 🌱 I’m currently learning Build Ai APP applied NLP and Documents managment with Machine Learning ...
- 💞️ I’m looking to collaborate on Applied Machine Learning ON ERP Solutions...
- 📫 How to reach me ...

Saskw2010@gmail.com

<!---
saskw2010/saskw2010 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->




[![yt](https://github.com/acervenky/acervenky/blob/master/assets/yt.gif)](https://www.youtube.com/acervenky)[![in](https://github.com/acervenky/acervenky/blob/master/assets/in.gif)](https://www.linkedin.com/in/venkateshsurve/)[![blog](https://github.com/acervenky/acervenky/blob/master/assets/blog1.gif)](https://www.keytechvk.com/)



## Work Featured On :
<br/>
This last 3 years I'm learning more about Ai, DevOps,AWS and Azure  Machine learning so I can build more complex solutions.
<br/>


## Github Badges :
<a href="https://docs.github.com/en/developers" target="_blank"><img src="https://raw.githubusercontent.com/acervenky/acervenky/master/assets/devbadge.gif" width="40" height="40"></a>  <a href="https://archiveprogram.github.com/" target="_blank"><img src="https://raw.githubusercontent.com/acervenky/acervenky/master/assets/acbadge.gif" width="40" height="40"></a> 





## ⚡ Technologies
 * Blazor, C# 🔥
 * .NET,.NET Core,VB.NET 💜
 * MAUI 🔥🤖
 * React 💻 , Angular 🌐
 * Xamarin 📱
 * Python 🐍
![JavaScript](https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript)
![Nodejs](https://img.shields.io/badge/-Nodejs-black?style=flat-square&logo=Node.js)
![React](https://img.shields.io/badge/-React-black?style=flat-square&logo=react)
![TypeScript](https://img.shields.io/badge/-TypeScript-007ACC?style=flat-square&logo=typescript)
![Python](https://img.shields.io/badge/-Python-black?style=flat-square&logo=Python)
![C++](https://img.shields.io/badge/-C++-00599C?style=flat-square&logo=c)
![HTML5](https://img.shields.io/badge/-HTML5-E34F26?style=flat-square&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/-CSS3-1572B6?style=flat-square&logo=css3)
![Bootstrap](https://img.shields.io/badge/-Bootstrap-563D7C?style=flat-square&logo=bootstrap)
![MongoDB](https://img.shields.io/badge/-MongoDB-black?style=flat-square&logo=mongodb)
![Redis](https://img.shields.io/badge/-Redis-black?style=flat-square&logo=Redis)
![GraphQL](https://img.shields.io/badge/-GraphQL-E10098?style=flat-square&logo=graphql)
![Apollo GraphQL](https://img.shields.io/badge/-Apollo%20GraphQL-311C87?style=flat-square&logo=apollo-graphql)
![PostgreSQL](https://img.shields.io/badge/-PostgreSQL-336791?style=flat-square&logo=postgresql)
![MySQL](https://img.shields.io/badge/-MySQL-black?style=flat-square&logo=mysql)
![Heroku](https://img.shields.io/badge/-Heroku-430098?style=flat-square&logo=heroku)
![Amazon AWS](https://img.shields.io/badge/Amazon%20AWS-232F3E?style=flat-square&logo=amazon-aws)
![Git](https://img.shields.io/badge/-Git-black?style=flat-square&logo=git)
![GitHub](https://img.shields.io/badge/-GitHub-181717?style=flat-square&logo=github)
![GitLab](https://img.shields.io/badge/-GitLab-FCA121?style=flat-square&logo=gitlab)
![BitBucket](https://img.shields.io/badge/-BitBucket-darkblue?style=flat-square&logo=bitbucket)

![Github Stats](https://github-readme-stats.vercel.app/api?username=saskw2010&count_private=true&show_icons=true&include_all_commits=true)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=saskw2010&hide=TeX&layout=compact)

<div id="header" align="center">
  <img src="https://github.com/saskw2010/saskw2010/blob/main/272685175_4748606475194021_8302047958663111005_n.jpg"  width="600" height="300"/>
  <br/>
  <img src="https://github.com/saskw2010/saskw2010/blob/main/455023732_185647.jpg"  width="600" height="900"/>
  <br/>
  <img src="https://github.com/saskw2010/saskw2010/blob/main/IMG-20220709-WA0034.jpg"  width="600" height="300"/>
  <br/>
  <img src="https://github.com/saskw2010/saskw2010/blob/main/WhatsApp%20Image%202022-12-21%20at%209.14.07%20AM.jpeg"  width="600" height="900"/>
 
 
 </div>
 
 <div id="header" align="center">
  
   ![Visitor Badge](https://visitor-badge.laobi.icu/badge?page_id=saskw2010)
  
  </div>

